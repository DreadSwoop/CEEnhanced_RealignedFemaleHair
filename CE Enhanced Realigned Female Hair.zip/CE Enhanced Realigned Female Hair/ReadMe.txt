Hello,

In case you drunkenly stumbled upon this, this is the readme for the source files for the Realigned Female Hair mod for Conan Exiles, Enhanced version.

DESCRIPTION OF CONTENTS

These files consist of the old hair meshes for female hairs #3, 8, + 10 (in the Devkit they are 2, 7, and 9, respecively), small data tables with entries for the relevant hairstyles, and a ModController for performing the data table merger. The cover image was also included, use it if you want but it's certainly not required.

Note that I included hair #3 in a separate table as I wanted to preserve the mesh but not necessarily have it in use. If you wanted, you could copy that entry into the other table for old #3 to appear, or tell the ModController to also perform a merger with the reserve table.

INSTALLATION

To add the mod into your DevKit, copy the 'RealignedFemaleHair' folder into the mod directory. From the main DevKit folder, the path will very likely be:

\CEUE5Devkit\UE4\Content\Mods

The mod should only need to be re-cooked (rebuilt) in the DevKit to become functional once again, unless Inflexion, Funcom, or whoever else decide to do some major renovations. 

MISCELLANEOUS

If you're interested in testing the mod in advance of publishing or simply for your own use, you can copy the cooked pak file to the Mods folder in your game files and then enable in the main menu.

The pak file uses the name of the RealignedFemaleHair folder in the DevKit and not the mod name in the DevKit's Info Panel. To change the name of the pak (if you want), you can copy the contents of the folder to one with the new name, though you'd have to fix broken references in the ModController's Data Table Operations section as well as potentially the data tables.

CONCLUSION

Hopefully that covers the basics, I look forward to seeing your version (provided you don't blow it, of course)! If you're the first to re-upload, let me know and I'll provide a link to your mod page.

Thanks for reading,

Dread Swoop